/**---------------------------------------------------------------------
 * fft here.
 */
extern const uint32_t may_war_set_fft[NUM_TEB_FFT][2]={
    {0,2},{0,2},{0,2},{0,2},{0,2},
    {0,2},{0,2},{0,2}
};
extern const uint8_t teb_breaking_fft[NUM_TEB_FFT]={
    0, 0, 0, 0, 0,
    0, 0, 0
};
